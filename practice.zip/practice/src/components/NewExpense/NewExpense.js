import './NewExpense.css';
import ExpenseForm from './ExpenseForm';
import { useState } from 'react';
const NewExpense = (props) => {
  const [isEditing, setIsEditing] = useState(false)
  const startEditingHandler = () => {
    setIsEditing(true);
  }
  const stopEditingHandler = () => {
    setIsEditing(false);
  }
  const onSaveExpenseDatahandler = (enteredExpenseData) => {
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString(),
    };
    setIsEditing(false);
    props.onAddExpense(expenseData);

  }


    return (
        <div className='new-expense'>
          {!isEditing && <button onClick={startEditingHandler}>Add Expense</button>}
        {isEditing && 
        <ExpenseForm 
        onSaveExpenseData={onSaveExpenseDatahandler} 
        onCancel = {stopEditingHandler}/>
        }
        </div>
      );
};

export default NewExpense;