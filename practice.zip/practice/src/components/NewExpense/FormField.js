import './ExpenseForm.css';

const FormField = () => {
    <div className='new-expense__control'>
        <label>Title</label>
        <input type='text' onChange={titleChangeHandler} />
    </div>
}

export default FormField;