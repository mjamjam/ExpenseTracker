import Card from '../UI/Card';
import ExpensesList from './ExpensesList';
import './Expenses.css';
import ExpenseFilter from './ExpenseFilter';
import { useState } from 'react';
import ExpensesChart from './ExpenseChart';
const Expenses = (props) => {

  const [filteredYear, setFilteredYear] = useState('2020');

  const filterChangeHandler = selectedYear => {
    setFilteredYear(selectedYear);
    console.log(selectedYear)
  };
  const filteredExpenses = props.items.filter((item) => {
    return item.date.getFullYear().toString() === filteredYear
  });



  return (
    <Card className="expenses">
      <ExpensesChart expenses={filteredExpenses} />
      <ExpenseFilter selected={filteredYear} onChangeFilter={filterChangeHandler} />
      
      <ExpensesList items = {filteredExpenses} />
    </Card>
  );
}

export default Expenses;